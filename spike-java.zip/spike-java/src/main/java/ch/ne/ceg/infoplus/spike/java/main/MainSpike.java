package ch.ne.ceg.infoplus.spike.java.main;

import java.io.IOException;

import ch.ne.ceg.infoplus.spike.java.core.utils.FileUtils;


public class MainSpike {

	public static void main(String[] argc) throws IOException {
		System.out.println("Welcome Student Prg V0.1 Beta Make date 1.9.2016 \n");
		System.out.println("Domenico Roselli\n");
		System.out.println("1-09-2016 Last revision\n");
		System.out.println("\n");
		System.out.println("Lanciare Test Unitario JUnit");
		System.out.println("\n");
	}

}
